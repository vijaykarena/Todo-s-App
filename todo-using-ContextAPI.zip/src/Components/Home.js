import React from "react";
import "./Home.css";
import { AppContext } from "./useContext";
import { useContext } from "react";

const Home = () => {
  const ctx = useContext(AppContext);

  const addTodoHandler = (e) => {
    e.preventDefault();
    ctx.setTask(ctx.task);
    console.log(ctx.task);
    ctx.setTasks((prevTask) => {
      return [...prevTask, ctx.task];
    });
    ctx.setTask("");
  };

  const handleTodoInputChange = (e) => {
    ctx.setTask(e.target.value);
  };

  return (
    <>
      <section className="border">
        <div className="mb-3">
          <label htmlFor="todo" className="form-label mt-3">
            Enter your task here 😀
          </label>
          <input
            type="text"
            name="task"
            value={ctx.task}
            className="form-control"
            id="todo"
            onChange={handleTodoInputChange}
          />
          <button className="btn btn-primary mt-3" onClick={addTodoHandler}>
            Add todo
          </button>
        </div>
      </section>
      <br />
    </>
  );
};

export default Home;
