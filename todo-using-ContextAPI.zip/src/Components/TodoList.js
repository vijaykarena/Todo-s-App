import React, { useContext } from "react";
import { AppContext } from "./useContext";
import "./TodoList.css";

const TodoList = () => {
  const ctx = useContext(AppContext);
  return (
    <>
      {ctx.tasks.map((taskItem) => {
        return (
          <div>
            <section className="border">
              <div className="row">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                  />
                  <label
                    className="form-check-label"
                    htmlFor="flexCheckDefault"
                  >
                    {taskItem}
                  </label>
                </div>
              </div>
            </section>
            <br />
          </div>
        );
      })}
    </>
  );
};

export default TodoList;
