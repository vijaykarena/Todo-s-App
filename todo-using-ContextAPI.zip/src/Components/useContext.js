import { createContext, useState } from "react";

const AppContext = createContext();

const AppProvider = (props) => {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);
  return (
    <AppContext.Provider value={{ task, setTask, tasks, setTasks }}>
      {props.children}
    </AppContext.Provider>
  );
};

export { AppContext, AppProvider };
