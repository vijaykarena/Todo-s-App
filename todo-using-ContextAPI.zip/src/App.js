import "./App.css";
import Home from "./Components/Home";
import TodoList from "./Components/TodoList";
import { useContext } from "react";
import { AppContext } from "./Components/useContext";

function App(props) {
  const ctx = useContext(AppContext);

  console.log(ctx);
  return (
    <>
      <div className="container">
        <h3>Todo's List</h3>

        <Home />
        <TodoList />
      </div>
    </>
  );
}

export default App;
